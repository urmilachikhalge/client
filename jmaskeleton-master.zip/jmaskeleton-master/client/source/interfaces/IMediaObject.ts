export interface IMediaObject{
    id:string;
    url:string;
    altText : string;    
}