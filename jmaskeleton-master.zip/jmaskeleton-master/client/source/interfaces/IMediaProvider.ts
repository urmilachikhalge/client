export interface IMediaProvider {
    id : string;
    name : string;
}