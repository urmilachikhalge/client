import * as Jma from '../../interfaces/all-interfaces';
import {EventAggregator} from 'aurelia-event-aggregator';
import {UiService} from '../../services/ui-service';
import {bindable, inject, customElement} from 'aurelia-framework';

export class MainMenu {

}